import java.util.List;

public class SubtractionFormula implements Formula<Integer> {
    private int value;

    @Override
    public void compute(List<Cell<Integer>> cells) {
        if (cells.size() != 0){
            this.value = cells.get(0).getValue() * 2;
            for (Cell<Integer> cell : cells) {
                this.value -= cell.getValue();
            }
        }
        else {
            this.value = 0;
        }

    }

    @Override
    public Integer getValue() {
        return value;
    }

}
