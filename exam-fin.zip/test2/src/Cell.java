public interface Cell<E> extends Subject{
    E getValue();
}
