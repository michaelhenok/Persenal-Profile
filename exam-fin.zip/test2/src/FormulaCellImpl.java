import java.util.ArrayList;
import java.util.List;

public class FormulaCellImpl implements FormulaCell<Integer>{
    private List<Cell<Integer>> cells;
    private int value;
    private Formula<Integer> formula;
    private List<CellObserver> observers;

    public FormulaCellImpl(List<Cell<Integer>> cells, Formula<Integer> formula) {
        this.cells = cells;
        this.observers = new ArrayList<>();
        for (Cell<Integer> cell : this.cells) {
            cell.addObserver(this);
        }
        this.formula = formula;
        this.formula.compute(this.cells);
        this.value = this.formula.getValue();
    }

    @Override
    public Integer getValue() {
        return this.value;
    }

    @Override
    public void addObserver(CellObserver observer) {
        this.observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (CellObserver observer : this.observers) {
            observer.update();
        }
    }

    @Override
    public void update() {
        this.formula.compute(cells);
        this.value = formula.getValue();
        notifyObservers();
    }

    @Override
    public FormulaCell<Integer> addFormula(Formula<Integer> formula, Cell<Integer> cell) {
        FormulaCell<Integer> currentCell = new FormulaCellImpl(this.cells, this.formula);
        List<Cell<Integer>> newCells = new ArrayList<>();
        newCells.add(currentCell);
        newCells.add(cell);
        this.cells = newCells;
        this.formula = formula;

        this.formula.compute(this.cells);
        this.value = this.formula.getValue();
        this.observers = new ArrayList<>();
        for (Cell<Integer> c : this.cells) {
            c.addObserver(this);
        }

        return this;
    }

    @Override
    public void addCell(Cell<Integer> cell) {
        cell.addObserver(this);
        this.cells.add(cell);
        this.formula.compute(this.cells);
        this.value = this.formula.getValue();
    }

    @Override
    public String toString() {
        return getValue().toString();
    }


}
