public interface Subject {
    void addObserver(CellObserver observer);
    void notifyObservers();
}
