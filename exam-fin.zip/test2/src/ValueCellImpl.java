import java.util.ArrayList;
import java.util.List;

public class ValueCellImpl implements ValueCell<Integer>{
    private int value;
    private List<CellObserver> observers;

    public ValueCellImpl(int value) {
        this.value = value;
        this.observers = new ArrayList<>();
    }

    @Override
    public Integer getValue() {
        return value;
    }

    @Override
    public void addObserver(CellObserver observer) {
        this.observers.add(observer);
    }

    @Override
    public void notifyObservers() {
        for (CellObserver observer : this.observers) {
            observer.update();
        }
    }

    @Override
    public void setValue(Integer value) {
        this.value = value;
        notifyObservers();
    }

    @Override
    public String toString() {
        return getValue().toString();
    }
}
