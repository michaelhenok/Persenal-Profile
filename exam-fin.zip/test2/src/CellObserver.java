public interface CellObserver {
    void update();
}
