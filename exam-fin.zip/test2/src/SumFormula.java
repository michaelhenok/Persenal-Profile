import java.util.List;

public class SumFormula implements Formula<Integer> {
    private int value;

    @Override
    public void compute(List<Cell<Integer>> cells) {
        this.value = 0;
        for (Cell<Integer> cell : cells) {
            this.value += cell.getValue();
        }
    }

    @Override
    public Integer getValue() {
        return value;
    }

}
