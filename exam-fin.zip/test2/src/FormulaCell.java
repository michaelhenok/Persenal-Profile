public interface FormulaCell<E> extends ReferenceCell<E>, CellObserver {
    FormulaCell<E> addFormula(Formula<E> formula, Cell<E> cell);
    void addCell(Cell<E> cell);
}
