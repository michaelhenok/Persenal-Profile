public interface ValueCell<E> extends ReferenceCell<E>{
    void setValue(E value);
}
