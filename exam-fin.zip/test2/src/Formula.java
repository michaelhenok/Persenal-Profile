import java.util.List;

public interface Formula<E> {
    void compute(List<Cell<E>> cells);
    E getValue();
}
