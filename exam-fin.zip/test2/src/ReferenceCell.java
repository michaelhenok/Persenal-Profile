public interface ReferenceCell<E> extends Cell<E>{
}
